from flask import Flask, jsonify
from flask_cors import CORS
import mysql.connector
import json
import paho.mqtt.client as mqtt

app = Flask(__name__)
CORS(app)

# ---------------- MYSQL CONFIG ----------------
db = mysql.connector.connect(
    host="localhost",
    user="root",
    password="",
    database="machine_data"
)
cursor = db.cursor()

# ---------------- MQTT CONFIG ----------------
MQTT_BROKER = "cd64d83d595c41e6b93dee16893ae18c.s1.eu.hivemq.cloud"
MQTT_PORT   = 8883
MQTT_USER   = "Sunil"
MQTT_PASS   = "Project@1234"
MQTT_TOPIC  = "optimus"

client = mqtt.Client()
client.username_pw_set(MQTT_USER, MQTT_PASS)
client.tls_set()      # enable SSL/TLS

# ---------------- MQTT CALLBACK ----------------
def on_connect(client, userdata, flags, rc):
    print("MQTT Connected with rc:", rc)
    client.subscribe(MQTT_TOPIC)

def on_message(client, userdata, msg):
    print("Incoming MQTT Data:", msg.payload.decode())
    
    data = json.loads(msg.payload.decode())

    sql = """
        INSERT INTO machine_data (machine_id, vibration_raw, vibration_smooth, speed_rpm)
        VALUES (%s, %s, %s, %s)
    """
    values = (
        data["machine_id"],
        data["vibration_raw"],
        data["vibration_smooth"],
        data["speed_rpm"]
    )
    cursor.execute(sql, values)
    db.commit()

client.on_connect = on_connect
client.on_message = on_message
client.connect(MQTT_BROKER, MQTT_PORT)
client.loop_start()

# ---------------------------------------------------
#               API ENDPOINTS
# ---------------------------------------------------

@app.route("/")
def home():
    return {"message": "Flask + MQTT + MySQL running!"}

# ⬇️ FETCH ALL DATA (NO DATE FILTERS — ALWAYS VISIBLE)
@app.route("/getdata")
def getdata():
    cursor.execute("SELECT id, machine_id, vibration_raw, vibration_smooth, speed_rpm FROM machine_data ORDER BY id DESC")
    rows = cursor.fetchall()

    data = []
    for r in rows:
        data.append({
            "id": r[0],
            "machine_id": r[1],
            "vibration_raw": r[2],
            "vibration_smooth": r[3],
            "speed_rpm": r[4]
        })

    return jsonify(data)

# ---------------------------------------------------
#               RUN SERVER
# ---------------------------------------------------
if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0")
